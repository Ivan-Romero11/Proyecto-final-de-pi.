const editButtons = document.querySelectorAll('.btn-edit');
const deleteButtons = document.querySelectorAll('.btn-delete');

editButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Handle edit functionality here (logic might depend on your implementation)
        console.log('Edit button clicked for the corresponding table row');
    });
});

deleteButtons.forEach(button => {
    button.addEventListener('click', () => {
        const tableRow = button.closest('tr'); // Get the closest table row
        const userNameCell = tableRow.querySelector('td:nth-child(2)'); // Assuming username is in the 2nd column (adjust if needed)
        const userName = userNameCell.textContent.trim(); // Extract username text

        // Confirmation dialog with user-friendly message
        const confirmation = confirm(`Atención, está a punto de eliminar el usuario ${userName}. ¿Está seguro de que desea hacerlo?`);

        if (confirmation) {
            // If confirmed, proceed with deletion logic (e.g., sending a delete request to a server)
            console.log(`User confirmed deletion of ${userName}`);

            // Optionally, remove the table row visually to provide immediate feedback
            tableRow.remove();
        } else {
            console.log(`User canceled deletion of ${userName}`);
        }
    });
});